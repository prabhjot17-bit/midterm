//
//  Lab2ViewController.swift
//  Prabhjot_Kaur_MT_8963796
//
//  Created by user235216 on 3/10/24.
//

import UIKit

class Lab2ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    
    var count = 0
    var step = 1


    @IBOutlet weak var counter: UILabel!
    
    
    @IBAction func decrease(_ sender: Any) {
        count = count - step
        counter.text = String(count)
    }
    
    
    
    @IBAction func increase(_ sender: Any) {
        count = count + step
        counter.text = String(count)
    }
    
    
    
    @IBAction func reset(_ sender: Any) {
        count = 0
        counter.text = String(count)
        step = 1
    }
    
    
    
    @IBAction func step_value_two(_ sender: Any) {
        
        step = 2
    }

}
