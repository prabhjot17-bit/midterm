//
//  ViewController.swift
//  Prabhjot_Kaur_MT_8963796
//
//  Created by user235216 on 3/9/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

