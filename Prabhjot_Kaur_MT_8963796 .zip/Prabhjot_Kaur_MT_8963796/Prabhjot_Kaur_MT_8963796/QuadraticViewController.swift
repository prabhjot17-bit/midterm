//
//  QuadraticViewController.swift
//  Prabhjot_Kaur_MT_8963796
//
//  Created by user235216 on 3/9/24.
//

import UIKit

class QuadraticViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let backButton = UIBarButtonItem()
        backButton.title = "Quadratic Formula"
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        
    }
    
    
  
    @IBOutlet weak var textFieldA: UITextField!
    
  
    @IBOutlet weak var textFieldB: UITextField!
    
    
    @IBOutlet weak var textFieldC: UITextField!
    
    
    @IBOutlet weak var messageLabel: UITextView!
    
    
    @IBOutlet weak var outputLabel: UITextView!
    
    
    
    @IBAction func buttonCalculate(_ sender: Any) {
        
        self.view.endEditing(true)
            
            guard let a = Double(textFieldA.text ?? ""),
                  let b = Double(textFieldB.text ?? ""),
                  let c = Double(textFieldC.text ?? "") else {
                messageLabel.text = "Please enter values for a, b, and c"
                return
            }
            
            if a == 0 {
                messageLabel.text = "The value you entered for A is invalid."
                return
            }
            
            let discriminant = b * b - 4 * a * c
            
            if discriminant < 0 {
                messageLabel.text = "There are no results since the discriminant is less than zero."
                return
            } else if discriminant == 0 {
                let x = -b / (2 * a)
                outputLabel.text = "There is only one value for X: \(x)"
            } else {
                let root1 = (-b + sqrt(discriminant)) / (2 * a)
                let root2 = (-b - sqrt(discriminant)) / (2 * a)
                outputLabel.text = "There are two values for X: \(root1) and \(root2)"
            }
        
        
        
        
        
//        outputLabel.text = String(a)
//        outputLabel.text = (outputLabel.text ?? "") + String(b)
//        outputLabel.text = (outputLabel.text ?? "") + String(c)
        
        
        
        
    }
    
    // button to clear text inputs
    @IBAction func clearButton(_ sender: Any) {
        textFieldA.text = ""
        textFieldB.text = ""
        textFieldC.text = ""
        messageLabel.text = ""
        outputLabel.text = ""
    }
    
    
}
