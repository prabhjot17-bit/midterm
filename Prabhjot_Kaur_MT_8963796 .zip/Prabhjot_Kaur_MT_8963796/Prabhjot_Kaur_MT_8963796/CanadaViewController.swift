//
//  CanadaViewController.swift
//  Prabhjot_Kaur_MT_8963796
//
//  Created by user235216 on 3/9/24.
//

import UIKit

class CanadaViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func TextField(_ sender: Any) {
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    // Hide keyboard
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        
    }
    
    // city image
    @IBOutlet weak var image: UIImageView!
    
    
   // text field
    @IBOutlet weak var textField: UITextField!
    
    
    // button to change image according to city
    @IBAction func findMyCity(_ sender: Any) {
        
        if let cityName = textField.text?.lowercased() {
        switch cityName {
        case "calgary":
            image.image = UIImage(named: "Calgary")
        case "halifax":
            image.image = UIImage(named: "Halifax")
        case "toronto":
            image.image = UIImage(named: "Toronto")
        case "montreal":
            image.image = UIImage(named: "Montreal")
        case "vancouver":
            image.image = UIImage(named: "Vancouver")
        case "winnipeg":
            image.image = UIImage(named:"Winnipeg")
        default:
            image.image = UIImage(named:"Winnipeg")
                    }
                } else {
                    image.image = UIImage(named:"Winnipeg")

                }
    }

        
        
    
    
    
}
