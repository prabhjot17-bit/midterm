//
//  Lab3ViewController.swift
//  Prabhjot_Kaur_MT_8963796
//
//  Created by user235216 on 3/10/24.
//

import UIKit

class Lab3ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        
    }
    
    @IBOutlet weak var textFirstName: UITextField!
    
    @IBOutlet weak var textLastName: UITextField!
    
    
    @IBOutlet weak var textCountry: UITextField!
    
    
    @IBOutlet weak var textAge: UITextField!
    
    
    @IBOutlet weak var labelInvisible: UILabel!
    
    @IBOutlet weak var textView: UITextView!
    
    @IBAction func addButton(_ sender: Any) {
        
        let firstName = textFirstName.text
        let lastName = textLastName.text
        let country = textCountry.text
        let age = textAge.text
        
        if(firstName != "" || lastName != "") {
            textView.text = "Full Name: \(firstName ?? "") \(lastName ?? "") \n"
        }
        if(country != "") {
            textView.text! += "Country: \(country ?? "") \n"
        }
        if(age != "") {
            textView.text! += "Age: \(age ?? "")"
        }
        
    }
    
    @IBAction func submitButton(_ sender: Any) {
        let firstName = textFirstName.text
        let lastName = textLastName.text
        let country = textCountry.text
        let age = textAge.text
        
        if(firstName == "" || lastName == "" || country == "" || age == "") {
            labelInvisible.text = "Complete the missing information"
        }
        else{
            textView.text = "Full Name: \(firstName ?? "") \(lastName ?? "") \n"
            textView.text! += "Country: \(country ?? "") \n"
            textView.text! += "Age: \(age ?? "")"
            labelInvisible.text = "Submitted Successfully"
            
        }
    }
    
    
    @IBAction func clearButton(_ sender: Any) {
        textFirstName.text = ""
        textLastName.text = ""
        textCountry.text = ""
        textAge.text = ""
        labelInvisible.text = ""
        textView.text = ""
        
    }

}
